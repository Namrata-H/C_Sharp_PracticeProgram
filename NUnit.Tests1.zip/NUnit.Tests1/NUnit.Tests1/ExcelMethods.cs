﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;


namespace NUnit.Tests1
{
    [TestFixture]
    public class ExcelMethods
    {
        public string GetConnection(string filepath)
        {
            string connectionStr = "Provider = Microsoft.ACE.OLEDB.12.0;Data Source='" + filepath +
            "';Extended Properties=\"Excel 12.0;HDR=YES;\"";
            return connectionStr;
        }

        [Test]
        public void CreateAndEditExcel()
        {
            DataSet ds = new DataSet();
            string connectStr = GetConnection("C:\\Practice\\Trial");
            OleDbConnection conn = new OleDbConnection(connectStr);
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = conn;

            // Get all Sheets in Excel File
            DataTable dtSheet = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            // Loop through all Sheets to get data
            foreach (DataRow dr in dtSheet.Rows)
            {
                string sheetName = dr["TABLE_NAME"].ToString();

                if (!sheetName.EndsWith("$"))
                    continue;

                // Get all rows from the Sheet
                cmd.CommandText = "SELECT * FROM [" + sheetName + "]";

                DataTable dt = new DataTable();
                dt.TableName = sheetName;

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);

                ds.Tables.Add(dt);
            }

            cmd = null;
            conn.Close();

        }

     
    }
}
