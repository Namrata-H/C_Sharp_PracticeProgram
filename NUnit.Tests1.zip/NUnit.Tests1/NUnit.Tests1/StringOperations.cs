﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit.Tests1
{
    [TestFixture]
    public class StringOperations
    {
        [Test]
        public void ReverseString()
        {
            string input = "Alphabet";
            string reverseString = "";

            for (int i = input.Length - 1; i >= 0; i--)
            {
                reverseString = reverseString + input[i];
            }
            Console.WriteLine(reverseString);
        }

        [Test]
        public void SortString()
        {
            string str = "Animal";
            char temp;
            Char[] charStr = str.ToLower().ToCharArray();
            for (int i = 1; i < str.Length; i++)
            {
                for (int j = 0; j < str.Length - 1; j++)
                {
                    if (charStr[j] > charStr[j + 1])
                    {
                        temp = charStr[j];
                        charStr[j] = charStr[j + 1];
                        charStr[j + 1] = temp;
                    }

                }
            }

            Console.WriteLine(charStr);
        }


        [Test]
        public void PrintRightTriangleOfString()
        {
            string str = "INTERVIEW";

            for (int i = 0; i <= str.Length;i++)
            {
                for(int k =0; k<i; k++)
                {
                    Console.Write(str[k]);
                }
                Console.WriteLine();
            }
        }

        [Test]
        public void LengthOfLargestSubstring()
        {
             int NO_OF_CHARS = 256;
            string str = "Alphabetskjskd".ToLower();
            int i;
            int n = str.Length;

            // length of current substring 
            int cur_len = 1;

            // result 
            int max_len = 1;

            // previous index 
            int prev_index;

            int[] visited = new int[NO_OF_CHARS];

            /* Initialize the visited array as -1, -1 is  
            used to indicate that character has not been  
            visited yet. */
            for (i = 0; i < NO_OF_CHARS; i++)
            {
                visited[i] = -1;
            }

            /* Mark first character as visited by storing the 
                index of first character in visited array. */
            visited[str[0]] = 0;

            /* Start from the second character. First character is 
            already processed (cur_len and max_len are initialized 
            as 1, and visited[str[0]] is set */
            for (i = 1; i < n; i++)
            {
                prev_index = visited[str[i]];

                /* If the current character is not present in 
            the already processed substring or it is not 
                part of the current NRCS, then do cur_len++ */
                if (prev_index == -1 || i - cur_len > prev_index)
                    cur_len++;

                /* If the current character is present in currently 
                considered NRCS, then update NRCS to start from 
                the next character of the previous instance. */
                else
                {
                    /* Also, when we are changing the NRCS, we 
                    should also check whether the length of the 
                    previous NRCS was greater than max_len or 
                    not.*/
                    if (cur_len > max_len)
                        max_len = cur_len;

                    cur_len = i - prev_index;
                }

                // update the index of current character 
                visited[str[i]] = i;
            }

            // Compare the length of last NRCS with max_len and 
            // update max_len if needed 
            if (cur_len > max_len)
                max_len = cur_len;

            Console.WriteLine("largest Substring Length: " + max_len);
        }



    }
}
