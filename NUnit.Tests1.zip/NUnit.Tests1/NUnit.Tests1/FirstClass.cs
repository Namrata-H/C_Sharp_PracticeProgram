﻿// NUnit 3 tests
// See documentation : https://github.com/nunit/docs/wiki/NUnit-Documentation
using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace NUnit.Tests1
{
    [TestFixture]
    public class FirstClass
    {
        [Test]
        public void FindDuplicateCharactersinString()
        {
            string name = "Guddu";
            char[] charArr = name.ToLower().ToCharArray();
            Dictionary<char, int> duplicate = new Dictionary<char, int>();
            // add duplicate characters in a dictionary
            foreach(char val in charArr)
            {
                if(duplicate.ContainsKey(val))
                {
                    int value = duplicate[val];
                    value += 1;
                    duplicate[val] = value;
                }
                else
                {
                    duplicate.Add(val, 1);
                }
            }

            foreach(KeyValuePair<char,int> item in duplicate)
            {
                Console.WriteLine("Key: " + item.Key + " Value: " + item.Value);
            }
        }


        /*
         *
         **
         ***
         ****
         *****    
         */
        [Test]
        public void RightAngleTriangle()
        {
            for(int i=0; i<=5;i++)
            {
                for(int j=0; j<=i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

        }

        [Test]
        public void InvertedRightTriangle()
        {
            for (int i = 5; i >= 0; i--)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

        }

        [Test]
        public void PyramidPattern()
        {
            for(int i = 1; i<=5; i++)
            {
                for(int k =4; k>=i; k--)
                {
                    Console.Write(' ');
                }
                for(int j = 1; j<= (2*i -1); j++)
                {
                    Console.Write('*');
                }
                Console.WriteLine();
            }

        }

        [Test]
        public void InvertedPyramidPattern()
        {
            for (int i = 5; i >=1; i--)
            {
                for (int k = 5; k > i; k--)
                {
                    Console.Write(' ');
                }
                for (int j = 1; j < (2 * i); j++)
                {
                    Console.Write('*');
                }
                Console.WriteLine();
            }
        }

        [Test]
        public void PrimeNumbers()
        {
            int noOfPrimeNum = 100;
            bool isPrime = true;

            for(int i=2;i<=noOfPrimeNum;i++)
            {
                for(int j =2; j<=noOfPrimeNum;j++)
                {
                    if (i != j && i % j== 0)
                    {
                        isPrime = false;
                    }
                }
                if (isPrime)
                {
                    Console.WriteLine(i);
                }
                isPrime = true;
            }

            
        }
    }
}
